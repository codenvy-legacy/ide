# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Myapp::Application.config.secret_token = '555440e73e608609ec59ae42fddc051150cc2951bac49ea8fcd0bb15f5533629ac6aae566fca66ac7b6b225f990ab37d4cbe0b3eda8c73b45f4f7f69b5766af2'
