/**
 * Copyright (C) 2010 eXo Platform SAS.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.cloudide.sample.s3;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class S3ExceptionMapper implements ExceptionMapper<AmazonClientException>
{

   
   @Override
   public Response toResponse(AmazonClientException exception)
   {
      StringBuilder builder = new StringBuilder();
      if (exception instanceof AmazonServiceException)
      {
         builder
            .append(
               "Caught an AmazonServiceException, which means your request made it to Amazon S3, but was rejected with an error response for some reason.<br>")
            .append("Error Message:    ").append(exception.getMessage()).append("<br>").append("HTTP Status Code: ")
            .append(((AmazonServiceException)exception).getStatusCode()).append("<br>").append("AWS Error Code:   ")
            .append(((AmazonServiceException)exception).getErrorCode()).append("<br>").append("Error Type:       ")
            .append(((AmazonServiceException)exception).getErrorType()).append("<br>").append("Request ID:       ")
            .append(((AmazonServiceException)exception).getRequestId());
         return Response.status(500).entity(builder.toString()).type("text/plain").build();
      }
      else
      {
         if ("Empty key".equals(exception.getMessage()))
         {
            builder.append("Can not login to the S3 server.<br>Empty AWS Access Key ID or Secret Access Key.<br><br>")
                   .append("<span style=\"color:blue;\">The basic steps for running the Amazon S3 sample are:<br>")
                   .append("1. Open the  src/main/resources/AwsCredentials.properties in the project directory.<br>")
                   .append("2. Locate the following section and fill in your Access Key ID and Secret Access Key:<br>")
                   .append("# Fill in your AWS Access Key ID and Secret Access Key<br>")
                   .append("# http://aws.amazon.com/security-credentials<br>")
                   .append("accessKey = <br>")
                   .append("secretKey = <br>")
                   .append("3. Save the file.<br>")
                   .append("4. Run the S3 Sample Project. In main menu PaaS -> Elastic Beanstalk -> Manage Application... <br>")
                   .append("   In pop-up push \"Create New Version\"<br>") 
                   .append("5. Select \"Version\" tab. Push \"Deploy\" button for created version.</span>"); 

            return Response.status(403).entity(builder.toString()).type("text/plain").build();
         }
         builder.append("Caught an AmazonClientException, which means the client encountered ")
            .append("a serious internal problem while trying to communicate with S3, ")
            .append("such as not being able to access the network.<br>")
            .append("Error Message: " + exception.getMessage());
         return Response.status(400).entity(builder.toString()).type("text/plain").build();
      }
   }

}
