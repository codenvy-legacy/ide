package com.codenvy.ide.tutorial.wizard;

import com.codenvy.ide.api.extension.Extension;
import com.codenvy.ide.api.ui.action.ActionManager;
import com.codenvy.ide.api.ui.action.DefaultActionGroup;
import com.codenvy.ide.api.ui.wizard.DefaultWizard;
import com.codenvy.ide.api.ui.workspace.WorkspaceAgent;
import com.codenvy.ide.tutorial.wizard.action.OpenCustomWizardAction;
import com.codenvy.ide.tutorial.wizard.action.OpenSimpleWizardAction;
import com.codenvy.ide.tutorial.wizard.inject.SimpleWizard;
import com.codenvy.ide.tutorial.wizard.pages.page1.Page1Presenter;
import com.codenvy.ide.tutorial.wizard.pages.page2.Page2Presenter;
import com.codenvy.ide.tutorial.wizard.pages.page3.Page3Presenter;
import com.codenvy.ide.tutorial.wizard.pages.page4.Page4Presenter;
import com.codenvy.ide.tutorial.wizard.pages.pagex.PageXFactory;
import com.codenvy.ide.tutorial.wizard.part.TutorialHowToPresenter;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.google.inject.Singleton;

import static com.codenvy.ide.api.ui.action.IdeActions.GROUP_MAIN_MENU;
import static com.codenvy.ide.api.ui.workspace.PartStackType.EDITING;

/** Extension used to demonstrate the Wizard feature. */
@Singleton
@Extension(title = "Wizard tutorial", version = "1.0.0")
public class WizardTutorialExtension {

    @Inject
    public WizardTutorialExtension(CustomWizard customeWizard,
                                   @SimpleWizard DefaultWizard simpleWizard,
                                   ActionManager actionManager,
                                   Provider<Page1Presenter> page1,
                                   Provider<Page2Presenter> page2,
                                   Provider<Page3Presenter> page3,
                                   Provider<Page4Presenter> page4,
                                   PageXFactory factory,
                                   OpenCustomWizardAction openCustomWizardAction,
                                   OpenSimpleWizardAction openSimpleWizardAction,
                                   WorkspaceAgent workspaceAgent,
                                   TutorialHowToPresenter howToPresenter) {
        workspaceAgent.openPart(howToPresenter, EDITING);

        DefaultActionGroup mainMenu = (DefaultActionGroup)actionManager.getAction(GROUP_MAIN_MENU);

        DefaultActionGroup group = new DefaultActionGroup("Wizard", true, actionManager);
        actionManager.registerAction("Wizard", group);

        group.add(openCustomWizardAction);
        group.add(openSimpleWizardAction);
        mainMenu.add(group);

        customeWizard.addFirst(factory.create("PageF1"));
        customeWizard.addFirst(factory.create("PageF2"));

        customeWizard.addLast(page4.get());
        customeWizard.addLast(factory.create("PageL1"));
        customeWizard.addLast(factory.create("PageL2"));

        simpleWizard.addPage(page1.get());
        simpleWizard.addPage(page2.get());
        simpleWizard.addPage(page3.get());
        simpleWizard.addPage(page4.get());

        simpleWizard.addPage(factory.create("PageF1"), 1, false);
        simpleWizard.addPage(factory.create("PageF2"), 2, false);
        simpleWizard.addPage(factory.create("PageL1"));
        simpleWizard.addPage(factory.create("PageL2"));
    }
}