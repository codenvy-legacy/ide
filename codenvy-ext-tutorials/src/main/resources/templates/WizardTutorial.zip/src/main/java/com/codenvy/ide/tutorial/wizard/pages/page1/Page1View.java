/*
 * CODENVY CONFIDENTIAL
 * __________________
 *
 * [2012] - [2013] Codenvy, S.A.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Codenvy S.A. and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Codenvy S.A.
 * and its suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Codenvy S.A..
 */
package com.codenvy.ide.tutorial.wizard.pages.page1;

import com.codenvy.ide.api.mvp.View;

/** @author <a href="mailto:aplotnikov@codenvy.com">Andrey Plotnikov</a> */
public interface Page1View extends View<Page1View.ActionDelegate> {
    public interface ActionDelegate {
        void onPage2Chosen();

        void onPage3Chosen();

        void onPage4Clicked();
    }

    boolean isPage2Next();

    void setPage2Next(boolean page2Next);

    boolean isPage4Show();

    void setPage4Show(boolean skip);
}