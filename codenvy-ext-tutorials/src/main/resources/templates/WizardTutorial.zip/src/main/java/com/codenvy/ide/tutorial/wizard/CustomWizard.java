/*
 * CODENVY CONFIDENTIAL
 * __________________
 *
 * [2012] - [2013] Codenvy, S.A.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Codenvy S.A. and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Codenvy S.A.
 * and its suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Codenvy S.A..
 */
package com.codenvy.ide.tutorial.wizard;

import com.codenvy.ide.annotations.NotNull;
import com.codenvy.ide.api.ui.wizard.WizardContext;
import com.codenvy.ide.api.ui.wizard.WizardPage;
import com.codenvy.ide.json.JsonArray;
import com.codenvy.ide.json.JsonCollections;
import com.codenvy.ide.tutorial.wizard.pages.page1.Page1Presenter;
import com.codenvy.ide.tutorial.wizard.pages.page2.Page2Presenter;
import com.codenvy.ide.tutorial.wizard.pages.page3.Page3Presenter;
import com.google.gwt.user.client.Window;
import com.google.inject.Inject;
import com.google.inject.Singleton;

/** @author <a href="mailto:aplotnikov@codenvy.com">Andrey Plotnikov</a> */
@Singleton
public class CustomWizard implements com.codenvy.ide.api.ui.wizard.Wizard, WizardPage.CommitCallback {
    public static final WizardContext.Key<Boolean> PAGE2_NEXT = new WizardContext.Key<Boolean>("Page 2 next");
    public static final WizardContext.Key<Boolean> PAGE4_SKIP = new WizardContext.Key<Boolean>("Page 4 skip");
    private UpdateDelegate        delegate;
    private JsonArray<WizardPage> firstPages;
    private JsonArray<WizardPage> lastPages;
    private WizardContext         wizardContext;
    private Page1Presenter        page1;
    private JsonArray<WizardPage> flippedPages;
    private int                   index;
    private Page2Presenter        page2;
    private Page3Presenter        page3;

    @Inject
    public CustomWizard(Page1Presenter page1, Page2Presenter page2, Page3Presenter page3) {
        lastPages = JsonCollections.createArray();
        wizardContext = new WizardContext();
        firstPages = JsonCollections.createArray();
        lastPages = JsonCollections.createArray();
        flippedPages = JsonCollections.createArray();

        this.page1 = page1;
        this.page2 = page2;
        this.page3 = page3;
    }

    /** {@inheritDoc} */
    @Override
    public void setUpdateDelegate(@NotNull UpdateDelegate delegate) {
        this.delegate = delegate;
    }

    /** {@inheritDoc} */
    @Override
    public String getTitle() {
        return "Sample wizard";
    }

    /** {@inheritDoc} */
    @Override
    public WizardPage flipToFirst() {
        wizardContext.clear();
        flippedPages.clear();
        index = 0;

        addPage(page1, flippedPages);

        return page1;
    }

    /** {@inheritDoc} */
    @Override
    public WizardPage flipToNext() {
        if (index == 0 && !firstPages.isEmpty()) {
            for (WizardPage page : firstPages.asIterable()) {
                addPage(page, flippedPages);
            }
        }

        if (index == firstPages.size() && wizardContext.getData(PAGE2_NEXT)) {
            addPage(page2, flippedPages);
        } else if (index == firstPages.size() && !wizardContext.getData(PAGE2_NEXT)) {
            addPage(page3, flippedPages);
        }

        if (index == firstPages.size() + 1) {
            for (WizardPage page : lastPages.asIterable()) {
                addPage(page, flippedPages);
            }
        }

        while (++index < flippedPages.size()) {
            WizardPage page = flippedPages.get(index);
            if (!page.canSkip()) {
                return page;
            }
        }

        return null;
    }

    /** {@inheritDoc} */
    @Override
    public WizardPage flipToPrevious() {
        if (index <= 0) {
            return null;
        }

        boolean canSkip = true;
        while (canSkip && --index > 0) {
            WizardPage page = flippedPages.get(index);
            canSkip = page.canSkip();
        }

        if (index == 0) {
            for (WizardPage page : firstPages.asIterable()) {
                flippedPages.remove(page);
            }
        }

        if (index == firstPages.size()) {
            flippedPages.remove(index + 1);
        }

        if (index == firstPages.size() + 1) {
            for (WizardPage page : lastPages.asIterable()) {
                flippedPages.remove(page);
            }
        }

        return flippedPages.get(index);
    }

    /** {@inheritDoc} */
    @Override
    public boolean hasNext() {
        return !isLastPage();
    }

    /** {@inheritDoc} */
    @Override
    public boolean hasPrevious() {
        return index > 0;
    }

    /** {@inheritDoc} */
    @Override
    public boolean canFinish() {
        WizardPage page = flippedPages.get(index);
        return isLastPage() && page.isCompleted();
    }

    private boolean isLastPage() {
        Boolean data = wizardContext.getData(PAGE2_NEXT);
        if (index < firstPages.size()) {
            return !hasEnablePage(firstPages) && (data != null && data ? !page2.canSkip() : !page3.canSkip()) &&
                   !hasEnablePage(lastPages);
        }

        if (index == firstPages.size()) {
            return (data != null && data ? !page2.canSkip() : !page3.canSkip()) && !hasEnablePage(lastPages);
        }

        if (index == firstPages.size() + 1) {
            return !hasEnablePage(lastPages);
        }

        return hasNextPage();
    }

    private boolean hasEnablePage(JsonArray<WizardPage> pages) {
        for (WizardPage page : pages.asIterable()) {
            if (!page.canSkip()) {
                return true;
            }
        }
        return false;
    }

    private boolean hasNextPage() {
        for (int i = index + 1; i < flippedPages.size(); i++) {
            WizardPage page = flippedPages.get(i);
            if (!page.canSkip()) {
                return false;
            }
        }
        return true;
    }

    /** {@inheritDoc} */
    @Override
    public void onFinish() {
        index = 0;

        commit();
    }

    private void commit() {
        WizardPage page = flippedPages.get(index);
        page.commit(this);
    }

    public void addFirst(WizardPage page) {
        addPage(page, firstPages);
    }

    public void addLast(WizardPage page) {
        addPage(page, lastPages);
    }

    private void addPage(WizardPage page, JsonArray<WizardPage> pages) {
        page.setContext(wizardContext);
        page.setUpdateDelegate(delegate);
        pages.add(page);
    }

    /** {@inheritDoc} */
    @Override
    public void onSuccess() {
        if (++index < flippedPages.size()) {
            commit();
        } else {
            Window.alert("Success");
        }
    }

    /** {@inheritDoc} */
    @Override
    public void onFailure(@NotNull Throwable exception) {
        Window.alert(exception.getMessage());
    }
}