package org.exoplatform.sample;
class Employee {
  
  public String getSurname()
  {
    return "Ivanov";
  }
}