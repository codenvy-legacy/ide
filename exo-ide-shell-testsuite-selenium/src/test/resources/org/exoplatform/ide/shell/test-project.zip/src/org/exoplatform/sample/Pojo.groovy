package org.exoplatform.sample;
class Pojo
{

 String name;
 
 void printText(String text)
 {
  print text
 }

}