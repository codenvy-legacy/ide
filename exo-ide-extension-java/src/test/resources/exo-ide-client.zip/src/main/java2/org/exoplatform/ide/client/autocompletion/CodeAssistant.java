package org.exoplatform.ide.client.autocompletion;

public class CodeAssistant
{
  public void doCodeAssistant()
  {
    System.out.println("sdkjfksdf");
  }  
}
