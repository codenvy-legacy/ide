# Ruby Sample program
class HelloClass
  def sayHello
    puts( "Hello, wolrd!" )
  end
end

ob = HelloClass.new
ob.sayHello
