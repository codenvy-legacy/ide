package sumcontroller;
public class SumController {
int c = 225;
int d = 1;
public int sumForEdit (int a, int b)
{
return a+b;  
}
int ss = sumForEdit (c, d);

//For Find/replase test
String ONE ="";
String one ="";
}
