function objectTest () {
  var man = {   lastname: "Ivan",
	    firstname: "Mychaylovich", 
	    middlename: "kojdub"
	}
}

function stringTest(){
  var a ="Hello world";
  
 }


function arrayTest (){
  var arr = new Array("st","st2", "st3" );
  
 }

 function dateTest() {
  var date = new Date();
 
 }
 
 function booleanTest() {
   x = new Boolean(false);
   
  }
 
  function numberTest() {
   
   
 }
 
 function regExpTest() {
   
   
 }

 
 function jsonTest() {
   
   
 }
 
