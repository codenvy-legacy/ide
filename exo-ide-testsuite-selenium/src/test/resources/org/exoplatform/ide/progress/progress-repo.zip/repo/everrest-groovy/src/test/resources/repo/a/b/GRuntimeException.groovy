package a.b
class GRuntimeException extends RuntimeException
{
}