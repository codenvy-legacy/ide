package dependencies

class GDependency1
{
   String name = getClass().getName()
}