/**
 * Copyright (C) 2010 eXo Platform SAS.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.cloudide.sample.s3;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;


@Provider
public class S3ExceptionMapper implements ExceptionMapper<AmazonClientException>
{

   @Override
   public Response toResponse(AmazonClientException exception)
   {
      StringBuilder builder = new StringBuilder();
      if (exception instanceof AmazonServiceException)
      {
         builder
            .append(
               "Caught an AmazonServiceException, which means your request made it to Amazon S3, but was rejected with an error response for some reason.<br>")
            .append("Error Message:    ").append(exception.getMessage()).append("<br>").append("HTTP Status Code: ")
            .append(((AmazonServiceException)exception).getStatusCode()).append("<br>").append("AWS Error Code:   ")
            .append(((AmazonServiceException)exception).getErrorCode()).append("<br>").append("Error Type:       ")
            .append(((AmazonServiceException)exception).getErrorType()).append("<br>").append("Request ID:       ")
            .append(((AmazonServiceException)exception).getRequestId());
      }
      else
      {
         builder.append("Caught an AmazonClientException, which means the client encountered ")
            .append("a serious internal problem while trying to communicate with S3, ")
            .append("such as not being able to access the network.<br>")
            .append("Error Message: " + exception.getMessage());
      }
      return Response.status(500).entity(builder.toString()).type("text/plain").build();
   }
	
}
