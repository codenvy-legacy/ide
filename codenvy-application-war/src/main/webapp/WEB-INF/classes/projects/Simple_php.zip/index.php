<html>
  <head>
     <title>Hello World</title>
  </head>
  <body>
     <?php echo '<p>Hello World</p>'; ?>
  </body>
</html>
