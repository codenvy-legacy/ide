package com.codenvy.ide.ui.base;

public enum IconPosition {
    LEFT,RIGHT;
}
